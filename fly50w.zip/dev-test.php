<?php

use Fly50w\CLI\Merger;
use Fly50w\Lexer\Lexer;
use Fly50w\Parser\Parser;
use Symfony\Component\VarDumper\VarDumper;

require_once "vendor/autoload.php";

$lexer = new Lexer;

$tokens = $lexer->standardize($lexer->tokenize(
    Merger::mergeFile($argv[1])
));

// VarDumper::dump($tokens);

VarDumper::dump((new Parser)->parse($tokens));
