# Documention for fly50w

Welcome to the document of fly50w.

## 1. Basic Syntax

Note that

```fly50w

```
