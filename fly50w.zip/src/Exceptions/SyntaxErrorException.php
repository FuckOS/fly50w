<?php

namespace Fly50w\Exceptions;

class SyntaxErrorException extends \Exception
{
}
