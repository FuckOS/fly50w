<?php

namespace Fly50w\Exceptions;

class InvalidASTException extends \Exception
{
}
