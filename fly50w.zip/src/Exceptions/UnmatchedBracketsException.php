<?php

namespace Fly50w\Exceptions;

class UnmatchedBracketsException extends SyntaxErrorException
{
}
