<?php

namespace Fly50w\Exceptions;

class RuntimeException extends \Exception
{
}
