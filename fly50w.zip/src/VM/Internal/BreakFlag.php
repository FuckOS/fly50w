<?php

namespace Fly50w\VM\Internal;

class BreakFlag
{
}
