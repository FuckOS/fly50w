<?php

namespace Fly50w\VM\Internal;

class ReturnFlag
{
    public function __construct(
        public mixed $data = null
    ) {
    }
}
