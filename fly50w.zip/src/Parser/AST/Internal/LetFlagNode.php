<?php

namespace Fly50w\Parser\AST\Internal;

class LetFlagNode extends InternalNode
{
}
