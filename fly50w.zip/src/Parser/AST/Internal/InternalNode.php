<?php

namespace Fly50w\Parser\AST\Internal;

use Fly50w\Parser\AST\Node;

class InternalNode extends Node
{
}
