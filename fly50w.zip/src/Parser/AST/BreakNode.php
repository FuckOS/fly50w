<?php

namespace Fly50w\Parser\AST;

class BreakNode extends ExpressionNode
{
    protected int $maxNodes = 0;

    public function __construct()
    {
    }
}
