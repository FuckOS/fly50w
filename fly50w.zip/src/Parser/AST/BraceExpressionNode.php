<?php

namespace Fly50w\Parser\AST;

class BraceExpressionNode extends ExpressionNode
{
}
