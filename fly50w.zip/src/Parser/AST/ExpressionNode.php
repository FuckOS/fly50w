<?php

namespace Fly50w\Parser\AST;

class ExpressionNode extends Node
{
}
