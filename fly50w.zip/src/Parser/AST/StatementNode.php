<?php

namespace Fly50w\Parser\AST;

class StatementNode extends Node
{
    public function __construct()
    {
    }
}
