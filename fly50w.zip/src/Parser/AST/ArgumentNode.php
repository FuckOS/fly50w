<?php

namespace Fly50w\Parser\AST;

class ArgumentNode extends ExpressionNode
{
}
