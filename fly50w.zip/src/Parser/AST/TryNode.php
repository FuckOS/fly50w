<?php

namespace Fly50w\Parser\AST;

class TryNode extends ExpressionNode
{
}
